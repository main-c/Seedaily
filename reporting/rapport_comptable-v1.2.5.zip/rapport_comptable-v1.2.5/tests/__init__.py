"""
Tests unitaires du système d'automatisation de rapports comptables
"""

__version__ = "1.0"
